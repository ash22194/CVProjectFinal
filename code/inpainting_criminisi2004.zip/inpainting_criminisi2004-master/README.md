inpainting_criminisi2004
========================

MATLAB Implementation of inpainting Algorithm by A. Criminisi (2004)

This source code is highly referencing to below:
http://white.stanford.edu/teach/index.php/Object_Removal
http://en.pudn.com/downloads265/sourcecode/graph/detail1217180_en.html

## Reference

* Criminisi, Antonio, Patrick Pérez, and Kentaro Toyama. "Region filling and object removal by exemplar-based image inpainting." Image Processing, IEEE Transactions on 13.9 (2004): 1200-1212.
